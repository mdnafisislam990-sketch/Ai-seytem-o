package com.novaai.assistant.voice

import android.annotation.SuppressLint
import android.content.Context
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AudioEffect
import android.media.audiofx.NoiseSuppressor

/**
 * One microphone that is opened once and stays open (like a phone call).
 * It never restarts by itself, and has echo cancellation so it can keep listening while Nova talks.
 * Only [muted] or [stop] switch it off.
 */
class SteadyMic(
    private val ctx: Context?,
    private val onFrame: (ShortArray, Int) -> Unit,
    private val onFail: (String) -> Unit
) {
    @Volatile private var running = false
    @Volatile var muted = false
    private var th: Thread? = null
    private var am: AudioManager? = null
    private var oldMode = AudioManager.MODE_NORMAL
    private var oldSpeaker = false
    private var comm = false

    /** commMode = call-style audio (echo cancellation + loudspeaker), used for live voice. */
    fun start(commMode: Boolean) {
        if (running) return
        running = true; comm = commMode
        val c: Context? = ctx
        if (commMode && c != null) {
            runCatching {
                val a = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am = a; oldMode = a.mode; oldSpeaker = a.isSpeakerphoneOn
                a.mode = AudioManager.MODE_IN_COMMUNICATION
                a.isSpeakerphoneOn = true
                val max = a.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL)
                if (a.getStreamVolume(AudioManager.STREAM_VOICE_CALL) < max * 6 / 10) a.setStreamVolume(AudioManager.STREAM_VOICE_CALL, max * 8 / 10, 0)
            }
        }
        th = Thread { loop() }.also { it.isDaemon = true; it.start() }
    }

    fun stop() {
        running = false
        th?.interrupt(); th = null
        am?.let { a -> runCatching { a.mode = oldMode; a.isSpeakerphoneOn = oldSpeaker } }
        am = null
    }

    @SuppressLint("MissingPermission")
    private fun loop() {
        val rate = 16000
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val src = if (comm) MediaRecorder.AudioSource.VOICE_COMMUNICATION else MediaRecorder.AudioSource.VOICE_RECOGNITION
        val rec = try {
            AudioRecord(src, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 16000))
        } catch (e: Exception) { null }
        if (rec == null || rec.state != AudioRecord.STATE_INITIALIZED) { running = false; onFail("মাইক খুলতে পারিনি"); return }
        val fx = ArrayList<AudioEffect>()
        runCatching { if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(rec.audioSessionId)?.let { it.setEnabled(true); fx.add(it) } }
        runCatching { if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(rec.audioSessionId)?.let { it.setEnabled(true); fx.add(it) } }
        val buf = ShortArray(1600) // 100 ms
        var on = false
        try {
            while (running) {
                if (muted) {
                    if (on) { runCatching { rec.stop() }; on = false }
                    Thread.sleep(100)
                    continue
                }
                if (!on) { rec.startRecording(); on = true }
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) onFrame(buf, n) else Thread.sleep(30)
            }
        } catch (e: Exception) {
            if (running) { running = false; onFail("মাইক চালু রাখতে পারিনি") }
        } finally {
            runCatching { rec.stop() }
            runCatching { rec.release() }
            fx.forEach { runCatching { it.release() } }
        }
    }
}
